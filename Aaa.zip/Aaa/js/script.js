let input = "";
let result = "";

const HandleInput = numberPad => {
    input += numberPad;
    updateInput();   
}

const Sign = operator => {
    result += input;
    result += operator;
    input = "";
    console.log(result);
    updateInput();
}

const Equal = () => {
    result += input;
    input = "";
    result = toNumberFormatOfKor(eval(result).toFixed(4));
    document.querySelector("input").value = result;

}

const updateInput = () => {
    document.querySelector("input").value = toNumberFormatOfKor(input);
}

function toNumberFormatOfKor(num) { 
    return Number(num).toLocaleString('ko-KR');
}