let result = "1 + 2";
console.log(eval(result).toFixed(4));